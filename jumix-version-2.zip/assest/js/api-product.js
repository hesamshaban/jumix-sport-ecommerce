class apiFilterProduct{
    static #urlDate = "./assest/date/products.json"
    constructor(){

    }
    static async allApi(){
        let respon = await fetch(this.#urlDate);
        if(respon.ok && respon.status === 200){
            let date = await respon.json();
            return (date);
        }
        else{
            // throw new Error("error");
            return {error:true, status:respon.status , statusText:respon.statusText }
        }
    }
    async filterproduct(...filters){
        let allProducts = await apiFilterProduct.allApi();
        console.log(filters , Object.keys(filters[0]).join() , Object.values(filters[0]));
        let listFiltered = [];
        for (let item of filters){
            let filterKey = Object.keys(item).join();
            let filterValues = Object.values(item).join();
            let sucses = allProducts.filter((item)=>{
                return item[filterKey] === filterValues
            });
            listFiltered.push(sucses);
            
        }
        console.log(listFiltered);
        

        
    }
    async getApiById(id){
        let allProducts =await apiFilterProduct.allApi();
        let productById =allProducts.find((item)=>{
            return item.id === id;
        })
        return productById;
    }
}
async function call() {
    let x=await new apiFilterProduct().filterproduct({category:"Volleyball"} , {type:"performance"});
    console.log(x);
        
}

call();